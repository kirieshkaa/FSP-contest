"use client";
import React, { useState } from 'react'
import { useRouter } from 'next/navigation'

// Simple login page: root shows login; after login redirect to /dashboard
export default function LoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email.trim() && password.trim()) {
      router.push('/dashboard')
    } else {
      alert('Пожалуйста, введите Email и пароль')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-indigo-500 to-purple-600 p-6">
      <section className="w-full max-w-md bg-white/95 rounded-xl shadow-xl p-6">
        <h2 className="text-xl font-semibold mb-4 text-center">ВОЙТИ В СИСТЕМУ</h2>
        <form onSubmit={onSubmit}>
          <div className="mb-3">
            <label className="block text-xs uppercase tracking-wide mb-1">EMAIL</label>
            <input className="w-full px-3 py-2 rounded border" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} placeholder="user@example.com" required />
          </div>
          <div className="mb-3">
            <label className="block text-xs uppercase tracking-wide mb-1">ПАРОЛЬ</label>
            <input className="w-full px-3 py-2 rounded border" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="••••••••" required />
          </div>
          <button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded px-4 py-2" type="submit">Войти</button>
        </form>
      </section>
    </div>
  )
}
